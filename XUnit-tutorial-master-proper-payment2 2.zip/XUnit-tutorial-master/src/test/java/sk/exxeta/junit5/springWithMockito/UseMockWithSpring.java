package sk.exxeta.junit5.springWithMockito;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import sk.exxeta.service.text.ShowService;
import sk.exxeta.service.text.TextService;

@ExtendWith(MockitoExtension.class)
@DisplayName("Spring boot 2 mockito2 JUnit5 example")
public class UseMockWithSpring {
    private static final String MOCK_OUTPUT = "Mocked show label";

    @Mock
    private TextService textService;

    @InjectMocks
    private ShowService showService;

    @BeforeEach
    void setMockOutput() {
        when(textService.getText()).thenReturn(MOCK_OUTPUT);
    }

    @Test
    public void contextLoads() {
        assertEquals(showService.getShowLable(), MOCK_OUTPUT);
    }

}
