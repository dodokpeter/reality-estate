package sk.exxeta.service;

import sk.exxeta.model.BankOfExxeta;
import sk.exxeta.model.BankOfExxetaPaymentInfo;
import sk.exxeta.model.PaymentInfo;
import sk.exxeta.model.PaymentInfoDAO;
import sk.exxeta.model.TutorialException;
import sk.exxeta.repository.PaymentRepository;

import java.util.logging.Logger;

public class OrderService {
    private Logger LOGGER = Logger.getLogger(OrderService.class.getName());
    private BankOfExxeta bankOfExxeta;
    private PaymentRepository paymentRepository;

    public OrderService(BankOfExxeta bankOfExxeta, PaymentRepository paymentRepository) {
        this.bankOfExxeta = bankOfExxeta;
        this.paymentRepository = paymentRepository;
    }

    public void doPayment() {
        try {
            Thread.sleep(5000);// 5 seconds
        } catch (InterruptedException e) {
            LOGGER.info(e.getLocalizedMessage());
        }
    }

    public void doProperPayment(PaymentInfo paymentInfo) throws TutorialException{
        if(!validatePayment(paymentInfo)){
            throw new TutorialException("Invalid payment data.");
        }
        BankOfExxetaPaymentInfo bankOfExxetaPaymentInfo = bankOfExxeta.transform(paymentInfo);
        String resultId = bankOfExxeta.send(bankOfExxetaPaymentInfo);
        if(resultId != null && !resultId.isEmpty()) {
            paymentRepository.save(new PaymentInfoDAO(paymentInfo, resultId));
        }
        else {
            throw new TutorialException("Sending payment information failed.");
        }
    }

    private boolean validatePayment(PaymentInfo paymentInfo) {
        if(paymentInfo.getCCNumber().isEmpty()) return false;
        if(paymentInfo.getExpirationDate().isEmpty()) return false;
        if(paymentInfo.getCcv().isEmpty()) return false;
        if(paymentInfo.getCardHolder().isEmpty()) return false;
        if(paymentInfo.getAmount().isEmpty()) return false;
        return !paymentInfo.getCurrency().isEmpty();
    }
}