package sk.exxeta;


public class Util {

    /**
     * Determines whether a string is a palindrome.
     *   @param str the string to be tested
     *   @return true if the string is a palindrome; else, false
     */
    public static boolean isPalindrome(String str) {
        str = str.toLowerCase();
        str = Util.stripNonLetters(str);

        String reverseStr = Util.reverse(str);

        return (str.equals(reverseStr));
    }

    private static String reverse(String str) {
        String copy = "";
        for (int i = 0; i < str.length(); i++) {
            copy = str.charAt(i) + copy;
        }
        return copy;
    }

    private static String stripNonLetters(String str) {
        String copy = "";
        for (int i = 0; i < str.length(); i++) {
            if (Character.isLetter(str.charAt(i))) {
                copy += str.charAt(i);
            }
        }
        return copy;
    }
}
