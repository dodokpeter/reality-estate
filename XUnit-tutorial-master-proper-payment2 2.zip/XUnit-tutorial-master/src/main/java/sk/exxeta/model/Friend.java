package sk.exxeta.model;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class Friend {
    public static String isThatAFriend(String name) {
        if (name.equals("John") || name.equals("Luke")) {
            return "friend";
        }

        return "stranger";
    }
}
