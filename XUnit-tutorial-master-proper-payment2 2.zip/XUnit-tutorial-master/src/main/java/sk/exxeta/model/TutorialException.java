package sk.exxeta.model;

public class TutorialException extends Exception{
    public TutorialException(String message){
        super(message);
    }
}
