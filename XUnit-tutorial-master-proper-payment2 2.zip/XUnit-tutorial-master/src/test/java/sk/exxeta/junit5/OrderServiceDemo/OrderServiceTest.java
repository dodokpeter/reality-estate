package sk.exxeta.junit5.OrderServiceDemo;

import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import sk.exxeta.model.BankOfExxeta;
import sk.exxeta.model.BankOfExxetaImpl;
import sk.exxeta.model.BankOfExxetaPaymentInfo;
import sk.exxeta.model.PaymentInfo;
import sk.exxeta.model.PaymentInfoDAO;
import sk.exxeta.model.TutorialException;
import sk.exxeta.repository.PaymentRepository;
import sk.exxeta.service.OrderService;

import static org.mockito.ArgumentMatchers.any;

public class OrderServiceTest {

    private BankOfExxeta bankOfExxeta;
    private PaymentRepository paymentRepository;
    private OrderService orderService;

    @BeforeEach
    void init(){ //Initializing our test subject and creating mocks of required classes
        bankOfExxeta = Mockito.mock(BankOfExxetaImpl.class);
        //bankOfExxeta = new BankOfExxetaMock();
        paymentRepository = Mockito.mock(PaymentRepository.class);
        orderService = new OrderService(bankOfExxeta, paymentRepository);
    }

    @Test
    void doProperPaymentHappy() throws TutorialException {
        //Part 1: initializing test data
        PaymentInfo paymentInfo = new PaymentInfo(
                "4544123456789182",
                "01/28",
                "999",
                "Janko Hrasko",
                "3.50",
                "EUR"
        );
        BankOfExxetaPaymentInfo bankOfExxetaPaymentInfo = new BankOfExxetaPaymentInfo("test", "12345");
        PaymentInfoDAO paymentInfoDAO = new PaymentInfoDAO(paymentInfo, "12345");

        //Part 2: configuring mocks
        Mockito.when(bankOfExxeta.transform(paymentInfo)).thenReturn(bankOfExxetaPaymentInfo);
        Mockito.when(bankOfExxeta.send(bankOfExxetaPaymentInfo)).thenReturn("12345");
        Mockito.when(paymentRepository.save(paymentInfoDAO)).thenReturn(paymentInfoDAO);

        //Part 3: execution of the test
        orderService.doProperPayment(paymentInfo);

        //Part 4: verification
        Mockito.verify(bankOfExxeta, Mockito.times(1)).send(bankOfExxetaPaymentInfo);
        //Assert.assertTrue(((BankOfExxetaMock) bankOfExxeta).getSendCalledTimes() > 0);
        Mockito.verify(paymentRepository, Mockito.times(1)).save(paymentInfoDAO);
    }

    @Test
    void doProperPaymentFailedSend() {
        //Part 1: initializing test data
        PaymentInfo paymentInfo = new PaymentInfo(
                "4544123456789182",
                "01/28",
                "999",
                "Janko Hrasko",
                "3.50",
                "EUR"
        );
        BankOfExxetaPaymentInfo bankOfExxetaPaymentInfo = new BankOfExxetaPaymentInfo("test", "12345");

        //Part 2: configuring mocks
        Mockito.when(bankOfExxeta.transform(paymentInfo)).thenReturn(bankOfExxetaPaymentInfo);
        Mockito.when(bankOfExxeta.send(bankOfExxetaPaymentInfo)).thenReturn("");

        //Part 3: execution of the test and verification
        TutorialException tutorialException = Assertions.assertThrows(TutorialException.class, () -> orderService.doProperPayment(paymentInfo));
        Assert.assertEquals("Sending payment information failed.", tutorialException.getMessage());
    }

    @Test
    public void doProperPaymentInvalidData() throws TutorialException{
        //Part 1: initializing test data
        PaymentInfo paymentInfo = new PaymentInfo(
                "4544123456789182",
                "01/28",
                "999",
                "",
                "3.50",
                "EUR"
        );

        //Part 2: configuring mocks not needed

        //Part 3: execution of the test and verification
        TutorialException tutorialException = Assertions.assertThrows(TutorialException.class, () -> orderService.doProperPayment(paymentInfo));
        Assert.assertEquals("Invalid payment data.", tutorialException.getMessage());
    }
}
