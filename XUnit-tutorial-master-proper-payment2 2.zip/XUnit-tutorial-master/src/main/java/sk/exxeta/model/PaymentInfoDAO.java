package sk.exxeta.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PaymentInfoDAO {
    private PaymentInfo paymentInfo;
    private String correlationId;
}
