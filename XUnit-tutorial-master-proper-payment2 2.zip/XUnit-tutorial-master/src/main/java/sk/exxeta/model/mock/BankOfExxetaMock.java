package sk.exxeta.model.mock;

import sk.exxeta.model.BankOfExxeta;
import sk.exxeta.model.BankOfExxetaPaymentInfo;
import sk.exxeta.model.PaymentInfo;

public class BankOfExxetaMock implements BankOfExxeta {

    private int sendCalledTimes = 0;
    private int transformCalledTimes = 0;

    @Override
    public String send(BankOfExxetaPaymentInfo bankOfExxetaPaymentInfo) {
        sendCalledTimes = getSendCalledTimes() + 1;
        if(bankOfExxetaPaymentInfo.getInfoString().equals("test")) return "12345";
        else return "";
    }

    @Override
    public BankOfExxetaPaymentInfo transform(PaymentInfo paymentInfo) {
        transformCalledTimes = getTransformCalledTimes() + 1;
        return new BankOfExxetaPaymentInfo("test", "12345");
    }

    public int getSendCalledTimes() {
        return sendCalledTimes;
    }

    public int getTransformCalledTimes() {
        return transformCalledTimes;
    }
}
