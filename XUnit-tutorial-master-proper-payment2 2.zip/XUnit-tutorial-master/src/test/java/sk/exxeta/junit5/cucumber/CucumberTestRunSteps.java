package sk.exxeta.junit5.cucumber;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import sk.exxeta.model.Friend;

import static org.junit.Assert.assertEquals;

public class CucumberTestRunSteps {

    private String name;
    private String actualAnswer;

    @Given("I met a {string}")
    public void i_met_a(String string) {
        this.name = string;
    }

    @When("I asked whether it's a friend")
    public void i_asked_for_a_name() {
        this.actualAnswer = Friend.isThatAFriend(name);
    }

    @Then("I should know an {string}")
    public void i_should_know_an(String expectedAnswer) {
        assertEquals(expectedAnswer, actualAnswer);
    }
}
