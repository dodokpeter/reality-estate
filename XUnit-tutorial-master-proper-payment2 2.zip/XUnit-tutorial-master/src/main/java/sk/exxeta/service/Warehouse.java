package sk.exxeta.service;

public interface Warehouse {
    void add(String product, int amount);

    int getInventory(String product);

    void remove(String product, int amount);
}
