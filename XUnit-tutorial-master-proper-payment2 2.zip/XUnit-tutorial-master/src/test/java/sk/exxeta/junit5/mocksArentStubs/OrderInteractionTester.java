package sk.exxeta.junit5.mocksArentStubs;

import org.junit.jupiter.api.Test;
import sk.exxeta.model.Order;
import sk.exxeta.service.Warehouse;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Tests with Mock Objects - behavior verification
 *
 * https://martinfowler.com/articles/mocksArentStubs.html
 */
public class OrderInteractionTester {
    private static String TALISKER = "Talisker";

    @Test
    public void testFillingRemovesInventoryIfInStock() {
        //setup - data
        Order order = new Order(TALISKER, 50);
        Warehouse warehouseMock = mock(Warehouse.class);

        // setup
        when(warehouseMock.getInventory(TALISKER)).thenReturn(50);
        warehouseMock.remove(TALISKER, 50);

        // exercise
        order.fill((Warehouse) warehouseMock);

        // verify
        // warehouseMock.verify();
        assertTrue(order.isFilled());
    }

    @Test
    public void testFillingDoesNotRemoveIfNotEnoughInStock() {
        Order order = new Order(TALISKER, 51);
        Warehouse warehouseMock = mock(Warehouse.class);

        // setup
        when(warehouseMock.getInventory(any())).thenReturn(0);

        order.fill((Warehouse) warehouseMock);

        assertFalse(order.isFilled());
    }

}
