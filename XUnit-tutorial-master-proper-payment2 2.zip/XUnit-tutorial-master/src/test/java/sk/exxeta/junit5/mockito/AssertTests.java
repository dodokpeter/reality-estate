package sk.exxeta.junit5.mockito;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import sk.exxeta.model.BankOfExxeta;
import sk.exxeta.model.BankOfExxetaImpl;
import sk.exxeta.repository.PaymentRepository;
import sk.exxeta.service.OrderService;

import static java.time.Duration.ofSeconds;
import static org.junit.jupiter.api.Assertions.*;


public class AssertTests {


    @Test()
    void testGettingValue() {
        // get value
        Object value = Boolean.FALSE;
        assertNotNull(value);
    }
    @Test
    void testExpectedExceptionWithSuperType() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            Integer.parseInt("One");
        });
    }

    @Test
    public void doPaymentNotExceed10Seconds() {
        BankOfExxeta bankOfExxeta = Mockito.mock(BankOfExxetaImpl.class);
        PaymentRepository paymentRepository = Mockito.mock(PaymentRepository.class);
        OrderService orderService = new OrderService(bankOfExxeta, paymentRepository);
        assertTimeout(ofSeconds(10), () -> {
            // This method runs in 5 seconds
            orderService.doPayment();
        });
    }

    /**
     * This test will failed as a negative result
     */
    @Test
    @Disabled
    public void doPaymentExceed2Seconds() {
        BankOfExxeta bankOfExxeta = Mockito.mock(BankOfExxetaImpl.class);
        PaymentRepository paymentRepository = Mockito.mock(PaymentRepository.class);
        OrderService orderService = new OrderService(bankOfExxeta, paymentRepository);
        assertTimeout(ofSeconds(2), () -> {
            // This method runs in 5 seconds
            orderService.doPayment();
        } , "The doPayment method take more than 5 seconds");
    }

    @Test
    public void testAssertTrue() {
        assertTrue(true);
    }
}
