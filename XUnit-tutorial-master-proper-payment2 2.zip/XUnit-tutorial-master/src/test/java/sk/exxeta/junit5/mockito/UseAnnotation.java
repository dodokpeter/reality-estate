package sk.exxeta.junit5.mockito;

import org.junit.jupiter.api.*;

public class UseAnnotation {

    @BeforeAll
    public static void beforeClass() {
        System.out.println("Using @BeforeAll, executed only one time before all test cases.");
    }

    @BeforeEach
    public void beforeEachTest() {
        System.out.println("Using @BeforeEach, executed before each test cases.");
    }

    @Test
    public void test() {
        System.out.println("Using @Test, executed test cases.");
    }

    @Test
    public void anotherTest() {
        System.out.println("Using @Test, executed test cases.");
    }

    @AfterEach
    public void afterEachTest() {
        System.out.println("Using @AfterEach, executed after each test cases.");
    }

    @AfterAll
    public static void afterClass() {
        System.out.println("Using @AfterAll, executed only one time after all test cases.");
    }
}
