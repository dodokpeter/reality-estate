package sk.exxeta.junit5.mockito;


import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import sk.exxeta.Util;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;


public class ParametrizedTestDemo {

    @ParameterizedTest
    @ValueSource(strings = { "racecar", "radar", "able was I ere I saw elba" })
    void palindromes(String candidate) {
        assertTrue(Util.isPalindrome(candidate));
    }

    @ParameterizedTest
    @ValueSource(strings = { "some", "not a palindrome", "dummy" })
    void NotPalindromes(String candidate) {
        assertFalse(Util.isPalindrome(candidate));
    }


}
