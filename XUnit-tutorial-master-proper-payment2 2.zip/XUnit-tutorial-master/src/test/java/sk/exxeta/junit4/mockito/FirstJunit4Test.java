package sk.exxeta.junit4.mockito;

import org.junit.Test;

import static junit.framework.TestCase.assertTrue;

public class FirstJunit4Test {

    @Test
    public void test() {
        assertTrue(true);
    }
}
