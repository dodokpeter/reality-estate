package sk.exxeta.model;

import org.springframework.context.annotation.Bean;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.UUID;

public class BankOfExxetaImpl implements BankOfExxeta {
    @Override
    public String send(BankOfExxetaPaymentInfo bankOfExxetaPaymentInfo) {
        String result;
        try{
            URL url = new URL("http://example.com");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("POST");
            OutputStream os = con.getOutputStream();
            OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");
            osw.write(bankOfExxetaPaymentInfo.toString());
            osw.flush();
            osw.close();
            os.close();
            con.connect();
            BufferedInputStream bis = new BufferedInputStream(con.getInputStream());
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            int result2 = bis.read();
            while(result2 != -1) {
                buf.write((byte) result2);
                result2 = bis.read();
            }
            result = buf.toString();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return result;
    }

    public BankOfExxetaPaymentInfo transform(PaymentInfo paymentInfo){
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%20s", paymentInfo.getCCNumber()).replace(' ', '0'))
        .append(String.format("%20s", paymentInfo.getExpirationDate()).replace(' ', '0'))
        .append(String.format("%20s", paymentInfo.getCcv()).replace(' ', '0'))
        .append(String.format("%20s", paymentInfo.getCardHolder()).replace(' ', '0'))
        .append(String.format("%20s", paymentInfo.getAmount()).replace(' ', '0'))
        .append(String.format("%20s", paymentInfo.getCurrency()).replace(' ', '0'));
        return new BankOfExxetaPaymentInfo(sb.toString(), UUID.randomUUID().toString());
    }
}
