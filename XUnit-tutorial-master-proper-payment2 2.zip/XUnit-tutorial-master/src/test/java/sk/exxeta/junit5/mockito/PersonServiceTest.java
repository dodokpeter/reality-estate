package sk.exxeta.junit5.mockito;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import sk.exxeta.model.Person;
import sk.exxeta.repository.PersonRepository;
import sk.exxeta.service.PersonService;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class PersonServiceTest {

    private static Person person;
    private static List<String> skills;

    @Mock
    private PersonRepository personRepositoryMock;

    @InjectMocks
    private PersonService personService;

    @BeforeAll
    public static void init() {
        skills = new ArrayList<String>();
        skills.add("cooking");
        skills.add("leather tanning");
        skills.add("leadership");
        person = new Person("Janko", "Hrasko", "Nemsova", 19, 0.051, skills );
    }

    @Test
    public void testGetPersonByFirstNameAndLastName() {
        when(personRepositoryMock.findPersonByFirstNameAndLastName(anyString(), anyString())).thenReturn(Optional.of(person));

        Person result = personService.getPersonByFirstNameAndLastName(anyString(), anyString());

        assertNotNull(result);
        assertEquals(result.getLastName(), person.getLastName());
    }

    @Test
    public void testGetAllPersons() {
        List<Person> list = new ArrayList<Person>();
        list.add(person);
        when(personRepositoryMock.findAllPersons()).thenReturn(list);

        List<Person> result = personService.getAllPersons();

        assertNotNull(result);
        assertEquals(list.size(), 1);
        assertEquals(result.get(0).getFirstName(), person.getFirstName());
    }

    @Test
    public void testAddPerson() {
        when(personRepositoryMock.findPersonByFirstNameAndLastName(anyString(), anyString()))
            .thenReturn(Optional.empty());
        Person result = personService.addPerson(person);

        assertNotNull(result);
        assertEquals(result.getAddress(), person.getAddress());
    }

}
