package sk.exxeta.model;

import sk.exxeta.service.Warehouse;

public class Order {

    private String product;
    private int amount;
    private boolean filled;

    public Order(String product, int amount) {
        this.product = product;
        this.amount = amount;
        this.filled = false;
    }

    public void fill(Warehouse warehouse) {
        if( amount <= warehouse.getInventory(product)) {
            filled = true;
            warehouse.remove(product, amount);
        } else {
            filled = false;
        }
    }

    public boolean isFilled() {
        return filled;
    }
    public String getProduct() {
        return product;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}
