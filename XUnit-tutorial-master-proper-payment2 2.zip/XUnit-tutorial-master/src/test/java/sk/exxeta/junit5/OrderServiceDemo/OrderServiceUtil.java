package sk.exxeta.junit5.OrderServiceDemo;

import sk.exxeta.model.BankOfExxetaPaymentInfo;
import sk.exxeta.model.PaymentInfo;
import sk.exxeta.model.PaymentInfoDAO;

public class OrderServiceUtil {

    public static PaymentInfo getPaymentInfo(){
        return new PaymentInfo(
                "4544123456789182",
                "01/28",
                "999",
                "Janko Hrasko",
                "3.50",
                "EUR"
        );
    }

    public static PaymentInfo getInvalidPaymentInfo(){
        return new PaymentInfo(
                "4544123456789182",
                "01/28",
                "999",
                "",
                "3.50",
                "EUR"
        );
    }

    public static BankOfExxetaPaymentInfo getBankOfExxetaPaymentInfo(){
        return new BankOfExxetaPaymentInfo("test", "12345");
    }

    public static PaymentInfoDAO getPaymentInfoDAO(){
        return new PaymentInfoDAO(getPaymentInfo(), "12345");
    }
}
