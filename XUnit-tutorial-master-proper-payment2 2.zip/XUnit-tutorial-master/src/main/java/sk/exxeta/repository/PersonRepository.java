package sk.exxeta.repository;

import org.springframework.data.repository.CrudRepository;

import sk.exxeta.model.Person;

import java.util.List;
import java.util.Optional;

public interface PersonRepository extends CrudRepository<Person, Long> {

    List<Person> findAllPersons();

    Optional<Person> findPersonByFirstNameAndLastName(String firstName, String lastName);

}
