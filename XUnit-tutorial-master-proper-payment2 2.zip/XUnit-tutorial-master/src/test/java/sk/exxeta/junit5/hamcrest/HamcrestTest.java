package sk.exxeta.junit5.hamcrest;


import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import sk.exxeta.model.Person;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.hamcrest.collection.IsEmptyCollection.empty;
import static org.hamcrest.core.IsNull.notNullValue;
import static org.hamcrest.number.IsCloseTo.closeTo;
import static org.hamcrest.number.OrderingComparison.lessThan;
import static org.hamcrest.object.HasToString.hasToString;

//import static org.hamcrest.beans.HasProperty.hasProperty;

public class HamcrestTest {

    public static Person person;

    @BeforeAll
    public static void init() {
        List<String> skills = new ArrayList<String>();
        skills.add("cooking");
        skills.add("leather tanning");
        skills.add("leadership");
        person = new Person("Janko", "Hrasko", "Nemsova", 19, 0.051, skills );
    }

    /*
    *
    * Object Matcher
    *
     */
    @Test
    public void givenBean_whenToStringReturnsRequiredString_thenCorrect() {
        String str = person.toString();
        assertThat(person, hasToString(str));
    }

    /*
     *
     * Bean Matcher
     *
     */
    @Test
    public void givenBean_whenHasValue_thenCorrect() {
        assertThat(person, hasProperty("firstName"));
    }

    @Test
    public void givenBean_whenHasCorrectValue_thenCorrect() {
        String str = person.toString();
        assertThat(person, hasProperty("lastName", equalTo("Hrasko")));
    }

    /*
     *
     * Collection Matcher
     *
     */
    @Test
    public void givenCollection_whenEmpty_thenCorrect() {
        List<String> emptyList = new ArrayList<>();
        assertThat(emptyList, empty());
    }

    @Test
    public void givenAList_whenChecksSize_thenCorrect() {
        assertThat(person.getSkills(), hasSize(3));
    }

    @Test
    public void givenAListAndValues_whenChecksListForGivenValues_thenCorrect() {
        assertThat(person.getSkills(),
                containsInAnyOrder("leadership","cooking", "leather tanning"));
    }

    /*
     *
     * Number Matcher
     *
     */
    @Test
    public void givenAnInteger_whenLessThan0_thenCorrect() {
        assertThat(person.getAge(), lessThan(21));
    }

    @Test
    public void givenADouble_whenCloseTo_thenCorrect() {
        assertThat(person.getHeight(), closeTo(0.053, 0.005));
    }

    /*
     *
     * Text Matcher
     *
     */
    @Test
    public void givenString_whenEmptyOrNull_thenCorrect() {
        String str = null;
        assertThat(str, isEmptyOrNullString());
    }

    @Test
    public void given2Strings_whenEqual_thenCorrect() {
        assertThat(person.getLastName(), equalToIgnoringCase("HRASKO"));
    }

    /*
     *
     * Core API
     *
     */

    @Test
    public void givenAStrings_whenContainsAnotherGivenString_thenCorrect() {
        assertThat(person.getFirstName(), containsString("Jan"));
    }

    @Test
    public void givenString_whenNotNull_thenCorrect() {
        assertThat(person.getSkills(), notNullValue());
    }

//    @Test
//    public void givenString_whenMeetsAnyOfGivenConditions_thenCorrect() {
//        assertThat(person.getAddress(), anyOf(contains("Detva"), contains("Nemsova")));
//    }

}
