package sk.exxeta.junit5.mockito;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import sk.exxeta.model.Person;
import sk.exxeta.repository.PersonRepository;
import sk.exxeta.service.PersonService;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.mockito.BDDMockito.*;

@ExtendWith(MockitoExtension.class)
public class PersonServiceTest_BDDMockito {

    private static Person person;

    @Mock
    private PersonRepository personRepositoryMock;

    @InjectMocks
    private PersonService personService;

    @BeforeAll
    public static void init() {
        List<String> skills = new ArrayList<String>();
        person = new Person("Janko", "Hrasko", "Nemsova", 19, 0.051, skills );
    }

/*
    This test is using Mockito and we will write a test for using BDDMockito

    @Test
    public void testAddPerson() {
        when(personRepositoryMock.findPersonByFirstNameAndLastName(anyString(), anyString()))
            .thenReturn(Optional.empty());
        Person result = personService.addPerson(person);

        assertNotNull(result);
        assertEquals(result.getAddress(), person.getAddress());
    }
*/
    @Test
    public void testAddPerson() {
        // Given
        given(personRepositoryMock.findPersonByFirstNameAndLastName(anyString(), anyString()))
            .willReturn(Optional.empty());

        // When
        personService.addPerson(person);

        // Then
        then(personRepositoryMock)
            .should()
            .save(person);
    }
}
