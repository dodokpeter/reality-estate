package sk.exxeta.junit5.cucumber;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = {"pretty"},
        features = {"src/test/java/sk/exxeta/junit5/cucumber"},
        glue = {"sk.exxeta.junit5.cucumber"})
public class CucumberTest {
}
