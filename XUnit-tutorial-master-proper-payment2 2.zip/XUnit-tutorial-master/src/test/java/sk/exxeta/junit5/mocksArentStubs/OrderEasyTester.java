package sk.exxeta.junit5.mocksArentStubs;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.easymock.EasyMock.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class OrderEasyTester {

    @Test
    public void testFillingRemovesInventoryIfInStock() {
        // setup
        List mock = createNiceMock(List.class);

        expect(mock.get(0)).andStubReturn("one");
        expect(mock.get(1)).andStubReturn("two");

        replay(mock);

        //exercise
        Object res = mock.get(0);


        verify(mock);
        assertEquals("one", res);
    }
}
