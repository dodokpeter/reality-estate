package sk.exxeta.service;

import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sk.exxeta.model.Person;
import sk.exxeta.repository.PersonRepository;

import java.util.List;
import java.util.Optional;

@Service
@NoArgsConstructor
public class PersonService {

    @Autowired
    private PersonRepository personRepository;

    public Person addPerson(Person person) {
        if (!(personRepository.findPersonByFirstNameAndLastName(
                person.getFirstName(),
                person.getLastName()
            ).isPresent())) {
                personRepository.save(person);

                return person;
            } else {
                return null; // person with that first name and last name already exists
            }
    }

    public Person getPersonByFirstNameAndLastName(String firstName, String lastName) {
        Optional<Person> person = personRepository.findPersonByFirstNameAndLastName(firstName, lastName);
        if (person.isPresent()) {
            return person.get();
        } else {
            return null;
        }
    }

    public List<Person> getAllPersons() {
        return personRepository.findAllPersons();
    }
}
