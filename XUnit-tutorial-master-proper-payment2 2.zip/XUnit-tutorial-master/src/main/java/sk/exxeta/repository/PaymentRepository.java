package sk.exxeta.repository;

import org.springframework.data.repository.CrudRepository;
import sk.exxeta.model.PaymentInfoDAO;

public interface PaymentRepository extends CrudRepository<PaymentInfoDAO, Long> {
}
