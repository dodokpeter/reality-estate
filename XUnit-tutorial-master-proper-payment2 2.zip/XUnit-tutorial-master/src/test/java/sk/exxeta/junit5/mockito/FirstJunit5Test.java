package sk.exxeta.junit5.mockito;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class FirstJunit5Test {

    @Test
    public void test() {
        assertTrue(true);
    }
}
