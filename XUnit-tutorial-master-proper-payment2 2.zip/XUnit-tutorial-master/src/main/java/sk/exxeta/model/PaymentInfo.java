package sk.exxeta.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PaymentInfo {
    private String CCNumber;
    private String ExpirationDate;
    private String ccv;
    private String cardHolder;
    private String amount;
    private String currency;
}
