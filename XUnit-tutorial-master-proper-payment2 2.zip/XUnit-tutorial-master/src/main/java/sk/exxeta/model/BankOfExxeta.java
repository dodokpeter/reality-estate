package sk.exxeta.model;

import org.springframework.context.annotation.Bean;

public interface BankOfExxeta {
    public String send(BankOfExxetaPaymentInfo bankOfExxetaPaymentInfo);
    public BankOfExxetaPaymentInfo transform(PaymentInfo paymentInfo);
}
