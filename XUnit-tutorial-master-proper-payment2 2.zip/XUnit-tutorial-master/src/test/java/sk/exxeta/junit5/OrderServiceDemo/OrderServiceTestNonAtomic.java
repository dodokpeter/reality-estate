package sk.exxeta.junit5.OrderServiceDemo;

import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import sk.exxeta.model.BankOfExxeta;
import sk.exxeta.model.BankOfExxetaImpl;
import sk.exxeta.model.BankOfExxetaPaymentInfo;
import sk.exxeta.model.PaymentInfo;
import sk.exxeta.model.PaymentInfoDAO;
import sk.exxeta.model.TutorialException;
import sk.exxeta.repository.PaymentRepository;
import sk.exxeta.service.OrderService;

import static org.mockito.ArgumentMatchers.any;

public class OrderServiceTestNonAtomic {
    private BankOfExxeta bankOfExxeta;
    private PaymentRepository paymentRepository;
    private OrderService orderService;

    @BeforeEach
    void init(){ //Initializing our test subject and creating mocks of required classes
        bankOfExxeta = Mockito.mock(BankOfExxetaImpl.class);
        //bankOfExxeta = new BankOfExxetaMock();
        paymentRepository = Mockito.mock(PaymentRepository.class);
        orderService = new OrderService(bankOfExxeta, paymentRepository);

        Mockito.when(bankOfExxeta.transform(any(PaymentInfo.class))).thenReturn(OrderServiceUtil.getBankOfExxetaPaymentInfo());
        Mockito.when(bankOfExxeta.send(any(BankOfExxetaPaymentInfo.class))).thenReturn("12345");
        Mockito.when(paymentRepository.save(any(PaymentInfoDAO.class))).thenReturn(OrderServiceUtil.getPaymentInfoDAO());
    }

    @Test
    void doProperPaymentHappy() throws TutorialException {
        //Part 1: initializing test data

        //Part 2: configuring mocks

        //Part 3: execution of the test
        orderService.doProperPayment(OrderServiceUtil.getPaymentInfo());

        //Part 4: verification
        Mockito.verify(bankOfExxeta, Mockito.times(1)).send(any(BankOfExxetaPaymentInfo.class));
        Mockito.verify(paymentRepository, Mockito.times(1)).save(any(PaymentInfoDAO.class));
    }

    @Test
    void doProperPaymentFailedSend() {
        //Part 1: initializing test data

        //Part 2: configuring mocks
        Mockito.when(bankOfExxeta.send(any(BankOfExxetaPaymentInfo.class))).thenReturn("");

        //Part 3: execution of the test and verification
        TutorialException tutorialException = Assertions.assertThrows(TutorialException.class, () -> orderService.doProperPayment(OrderServiceUtil.getPaymentInfo()));
        Assert.assertEquals("Sending payment information failed.", tutorialException.getMessage());
    }

    @Test
    public void doProperPaymentInvalidData() throws TutorialException{
        //Part 1: initializing test data

        //Part 2: configuring mocks not needed

        //Part 3: execution of the test and verification
        TutorialException tutorialException = Assertions.assertThrows(TutorialException.class, () -> orderService.doProperPayment(OrderServiceUtil.getInvalidPaymentInfo()));
        Assert.assertEquals("Invalid payment data.", tutorialException.getMessage());
    }
}
