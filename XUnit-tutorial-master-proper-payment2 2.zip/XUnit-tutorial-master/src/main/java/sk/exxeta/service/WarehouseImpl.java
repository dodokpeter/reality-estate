package sk.exxeta.service;

import sk.exxeta.model.Order;

import java.util.ArrayList;
import java.util.List;

public class WarehouseImpl implements Warehouse {

    List<Order> orderList = new ArrayList<>();


    @Override
    public void add(String product, int amount) {
        orderList.add(new Order(product, amount));
    }

    @Override
    public int getInventory(String product) {
        for (Order o: orderList) {
            if (o.getProduct().equals(product)) {
                return o.getAmount();
            }
        }
        return 0;
    }

    @Override
    public void remove(String product, int amount) {
        for (Order o: orderList) {
            if (o.getProduct().equals(product)) {
                int idx = orderList.indexOf(o);
                o.setAmount(o.getAmount() - amount);
                orderList.set(idx, o);
            }
        }
    }
}
