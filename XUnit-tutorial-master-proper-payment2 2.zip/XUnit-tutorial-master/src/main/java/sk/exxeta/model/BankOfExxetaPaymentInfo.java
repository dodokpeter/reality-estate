package sk.exxeta.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class BankOfExxetaPaymentInfo {
    private String infoString;
    private String correlationId;
}
