Glossary
========

Annotations
-----------

#### @After
  JUnit 4 version of @AfterEach

#### @AfterAll

#### @AfterClass
  JUnit 4 version of @AfterAll

#### @AfterEach

#### @Before
  JUnit 4 version of @BeforeEach

#### @BeforeAll

#### @BeforeClass
  JUnit 4 version of @BeforeAll

#### @BeforeEach

#### @Category
  JUnit 4 version of @Tag

#### @ClassRule
  JUnit 4
  in JUnit 5 can be reproduced with @ExtendWith

#### @Disabled

#### @DisplayName

#### @ExtendWith

#### @Ignore
  JUnit 4 version of @Disabled

#### @Rule
  JUnit 4
  in JUnit 5 can be reproduced with @ExtendWith

#### @RunWith

#### @Tag

Assertion
---------

#### AssertAll

#### AssertTrue

Assumptions
-----------

#### assumingThat

other
-----

#### AfterEachCallback

  interface

#### BeforeEachCallback

  interface

#### expected

  JUnit 4:
  ```
  @Test(expected = Exception.class)
  ```
  JUnit 5:
  ```
  Assertions.assertThrows
  ```

see ...

#### timeout

  JUnit 4:
  ```
  @Test(timeout = 1)
  ```
  JUnit 5:
  ```
  Assertions.assertTimeout
  ```

see ...


