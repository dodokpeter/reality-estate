package sk.exxeta.junit5.mockito;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.platform.suite.api.IncludeTags;


@IncludeTags({"production", "development"})
public class UseTagInTest {

    @Test
    @Tag("development")
    public void testInDevelopment(TestInfo testInfo) {

    }

    @Test
    @Tag("production")
    public void testInProduction(TestInfo testInfo) {

    }

}
